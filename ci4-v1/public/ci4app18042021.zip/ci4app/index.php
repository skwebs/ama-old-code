<?php
header("Location: ./public");
?>