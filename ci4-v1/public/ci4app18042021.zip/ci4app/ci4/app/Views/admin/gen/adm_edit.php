<?php
echo "upload result";