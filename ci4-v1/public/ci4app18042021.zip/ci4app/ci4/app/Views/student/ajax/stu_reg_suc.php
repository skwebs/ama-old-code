<!-- content -->
<div class="bg-darkblue  p-4">
  <img style="width:99%; max-width:500px;" src="<?= base_url("assets/static/img/ama/ama-txt-w.png") ?>">
  <h1 class="d-none text-info">Anshu Memorial Academy <strong>Student Registration Form</strong>.</h1>
</div>
<div class="container-fluid">
  <p class="h3 my-4 text-success">Registration Successful</p>
  <hr class="hr m-0">

  <div class="card m-4 text-success border border-success">
    <div class="card-body">
      <p>Your Registration Number is <?= $reg_num ?> and Password is your D.o.B in DDMMYYYY format.</p>

      <a href="<?= site_url("student/login") ?>">Login Now</a>
    </div>
  </div>
</div>