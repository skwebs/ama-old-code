<?php

namespace App\Controllers;

class Nts extends BaseController
{
	public function index()
	{
		return view('welcome_message');
	}
}